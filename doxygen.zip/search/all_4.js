var searchData=
[
  ['starttime_0',['startTime',['../struct_timer.html#a776f35f97f4e03bed1685798da2dca92',1,'Timer']]],
  ['status_1',['status',['../struct_timer.html#ac8ad61d8e68ff59ef7ec304cc985fcdd',1,'Timer']]]
];
