var searchData=
[
  ['timer_0',['Timer',['../index.html',1,'(Global Namespace)'],['../struct_timer.html',1,'Timer']]],
  ['timer_2ec_1',['timer.c',['../timer_8c.html',1,'']]],
  ['timer_2eh_2',['timer.h',['../timer_8h.html',1,'']]],
  ['timer_5ffree_3',['timer_free',['../timer_8c.html#a07e626b7edc5ae9496e5b1815636d82b',1,'timer_free(uint8_t timerID):&#160;timer.c'],['../timer_8h.html#a07e626b7edc5ae9496e5b1815636d82b',1,'timer_free(uint8_t timerID):&#160;timer.c']]],
  ['timer_5fgettick_4',['timer_getTick',['../timer_8c.html#a5622dc12adf7b07e65f7e582d2dfd531',1,'timer_getTick():&#160;timer.c'],['../timer_8h.html#a5622dc12adf7b07e65f7e582d2dfd531',1,'timer_getTick():&#160;timer.c']]],
  ['timer_5finit_5',['timer_init',['../timer_8c.html#a184257ecc9e6152e611792d6bf51eae6',1,'timer_init():&#160;timer.c'],['../timer_8h.html#a184257ecc9e6152e611792d6bf51eae6',1,'timer_init():&#160;timer.c']]],
  ['timer_5fisexpired_6',['timer_isExpired',['../timer_8c.html#a8cacf2c96f1b21cad68442be733cb198',1,'timer_isExpired(uint8_t timerID):&#160;timer.c'],['../timer_8h.html#a8cacf2c96f1b21cad68442be733cb198',1,'timer_isExpired(uint8_t timerID):&#160;timer.c']]],
  ['timer_5fisrunning_7',['timer_isRunning',['../timer_8c.html#ad0973def4106c37fac3fa95ff28a6503',1,'timer_isRunning(uint8_t timerID):&#160;timer.c'],['../timer_8h.html#ad0973def4106c37fac3fa95ff28a6503',1,'timer_isRunning(uint8_t timerID):&#160;timer.c']]],
  ['timer_5fregister_8',['timer_register',['../timer_8c.html#afedd980f73d3b8f2c83f4556a1de6ddd',1,'timer_register(uint8_t *timerID, uint32_t period):&#160;timer.c'],['../timer_8h.html#afedd980f73d3b8f2c83f4556a1de6ddd',1,'timer_register(uint8_t *timerID, uint32_t period):&#160;timer.c']]],
  ['timer_5fregistercb_9',['timer_registerCB',['../timer_8c.html#a3265e19105e4171074a0f62d6e512785',1,'timer_registerCB(uint8_t *timerID, uint32_t period, timerType_t timerProcessType, action expiry):&#160;timer.c'],['../timer_8h.html#a3265e19105e4171074a0f62d6e512785',1,'timer_registerCB(uint8_t *timerID, uint32_t period, timerType_t timerProcessType, action expiry):&#160;timer.c']]],
  ['timer_5frun_10',['timer_run',['../timer_8c.html#adf55646b4779d6bdaa551e32ef9cd3f4',1,'timer_run():&#160;timer.c'],['../timer_8h.html#adf55646b4779d6bdaa551e32ef9cd3f4',1,'timer_run():&#160;timer.c']]],
  ['timer_5fsetperiod_11',['timer_setPeriod',['../timer_8c.html#a233005e1675b5d3d88376189325a5e81',1,'timer_setPeriod(uint8_t timerID, uint32_t period):&#160;timer.c'],['../timer_8h.html#a233005e1675b5d3d88376189325a5e81',1,'timer_setPeriod(uint8_t timerID, uint32_t period):&#160;timer.c']]],
  ['timer_5fstart_12',['timer_start',['../timer_8c.html#abceb64838a308e17f78886e3a995c9c2',1,'timer_start(uint8_t timerID):&#160;timer.c'],['../timer_8h.html#abceb64838a308e17f78886e3a995c9c2',1,'timer_start(uint8_t timerID):&#160;timer.c']]],
  ['timer_5ftimeremaining_13',['timer_timeRemaining',['../timer_8c.html#a1f7bc2fb6971e39defe791084463cd7d',1,'timer_timeRemaining(uint8_t timerID):&#160;timer.c'],['../timer_8h.html#a1f7bc2fb6971e39defe791084463cd7d',1,'timer_timeRemaining(uint8_t timerID):&#160;timer.c']]],
  ['timerretval_5ft_14',['timerRetVal_t',['../timer_8h.html#aa1a6d06068826b5535c8d27ae6b83fea',1,'timer.h']]]
];
